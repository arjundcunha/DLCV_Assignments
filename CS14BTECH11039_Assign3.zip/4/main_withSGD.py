import tensorflow as tf 
from tensorflow.contrib import rnn
import numpy as np 
from tensorflow.examples.tutorials.mnist import input_data

displayStep = 50
nInput = 28
nSteps = 28
nClasses = 10

def RNN(Cel, x, weights, biases, nHidden):
    x = tf.transpose(x, [1,0,2])
    x = tf.reshape(x, [-1, nInput])
    x = tf.split(axis=0, num_or_size_splits=nSteps, value=x) 
    if Cel == 'rnn':
        Cell = rnn.BasicRNNCell(nHidden)#find which lstm to use in the documentation
    elif Cel == 'lstm':
        Cell = rnn.BasicLSTMCell(nHidden)#find which lstm to use in the documentation
    else:
        Cell = rnn.GRUCell(nHidden)#find which lstm to use in the documentation

    outputs, states = rnn.static_rnn(Cell, x, dtype=tf.float32)#for the rnn where to get the output and hidden state 
    return tf.matmul(outputs[-1], weights['out']) + biases['out']

def runner(Cel, learningRate = 0.6e-3, trainingIters = 200000, batchSize = 128, nHidden = 128):   
    dataset = input_data.read_data_sets('MNIST_data', one_hot=True)
    tf.reset_default_graph()
    x = tf.placeholder('float', [None, nSteps, nInput])
    y = tf.placeholder('float', [None, nClasses])

    weights = {
        'out': tf.Variable(tf.random_normal([nHidden, nClasses]))
    }

    biases = {
        'out': tf.Variable(tf.random_normal([nClasses]))
    }
    
    pred = RNN(Cel,x, weights, biases, nHidden)
    
    cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=pred, labels=y))
    optimizer = tf.train.GradientDescentOptimizer(learning_rate=learningRate).minimize(cost)

    correctPred = tf.equal(tf.argmax(pred, 1), tf.argmax(y, 1))
    accuracy = tf.reduce_mean(tf.cast(correctPred, tf.float32))
    
    init = tf.global_variables_initializer()

    with tf.Session() as sess:
        sess.run(init)
        step = 1
        
        while step * batchSize < trainingIters:
            batchX, batchY = dataset.train.next_batch(batchSize)
            batchX = batchX.reshape((batchSize, nSteps, nInput))

            sess.run(optimizer, feed_dict={x: batchX, y: batchY})
            if step % displayStep == 0:
                acc = sess.run(accuracy, feed_dict={x: batchX, y: batchY})
                loss = sess.run(cost, feed_dict={x: batchX, y: batchY})
                print("Iter " + str(step*batchSize) + ", Minibatch Loss= " + \
                        "{:.6f}".format(loss) + ", Training Accuracy= " + \
                        "{:.5f}".format(acc))
            step +=1
        print('Optimization finished')
        
        testData = dataset.test.images.reshape((-1, nSteps, nInput))
        testLabel = dataset.test.labels
        return acc, loss, sess.run(accuracy, feed_dict={x: testData, y: testLabel})
